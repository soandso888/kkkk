myTV SUPER EPG 服务备份包
==========================
生成时间: 20260902
源服务器: 142.91.102.208

内容:
  epg_server.py    网页服务 (纯 Python 标准库, 零依赖, Basic Auth, 可选 HTTPS)
  epg_archive.sh   归档抓取脚本 (每6小时, 保留30天)
  mychannels.xml   iptv-org/epg 频道配置
  data/            XML 归档数据
  install.sh       一键部署脚本 (交互式向导 / 参数化两种模式)

部署 (目标机):
  tar xzf epg-bundle-*.tar.gz
  cd epg-bundle-*

  方式 A (交互式向导, 推荐):
    sudo bash install.sh
    依次选择: 端口 / 是否需要用户名+密码认证 / 用户名 / 密码

  方式 B (参数化, 适合自动化):
    sudo bash install.sh [端口] [用户名] [密码]
    例: sudo bash install.sh 8080 admin mypass   # 启用认证
    例: sudo bash install.sh 8080 none           # 不启用认证 (公开访问)

  可选: KEEP_ARCHIVE_CRON=1 sudo bash install.sh   # 同时注册归档定时任务

说明:
  - 网页服务零依赖, 全新 VPS 也能一键部署: 脚本会自动检测/安装 python3 (>=3.8),
    无需预装任何东西 (curl/wget 缺失也会自动安装)
  - 认证为 Basic Auth (用户名+密码), 可选择不启用 (公开访问)
  - 目标机若已有 /opt/epg/data 旧数据, 同名文件不会被覆盖
  - 归档抓取依赖 iptv-org/epg 框架 (nodejs + npm install), 新机若需持续归档,
    先按 iptv-org/epg 标准流程安装后再启用 KEEP_ARCHIVE_CRON
  - 防火墙需放行目标端口 (如 8765/tcp)
