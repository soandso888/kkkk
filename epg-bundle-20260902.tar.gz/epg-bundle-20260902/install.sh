#!/usr/bin/env bash
# ============================================================
# myTV SUPER EPG 一键部署 (目标机器执行, 需 root)
#
# 用法 A (交互式向导, 推荐):
#   sudo bash install.sh
#   依次选择: 端口 / 是否需要用户名+密码认证 / 用户名 / 密码
#
# 用法 B (非交互, 参数化):
#   sudo bash install.sh [端口] [用户名] [密码]
#   例: sudo bash install.sh 8080 admin mypass     # 启用认证
#   例: sudo bash install.sh 8080 none             # 不启用认证 (公开访问)
#
# 可选环境变量: KEEP_ARCHIVE_CRON=1 时自动注册归档定时任务
# ============================================================
set -euo pipefail

# ---------- 参数解析 ----------
if [ $# -ge 1 ]; then
  # 非交互: install.sh <port> [user] [pass]
  PORT="${1:-8765}"
  if [ $# -ge 2 ]; then
    AUTH_USER="${2}"
    if [ "$AUTH_USER" = "none" ] || [ "$AUTH_USER" = "-" ]; then
      AUTH_USER=""
      AUTH_PASS=""
    else
      AUTH_PASS="${3:-hugo2026+}"
    fi
  else
    AUTH_USER="admin"
    AUTH_PASS="hugo2026+"
  fi
  echo "== 非交互部署: 端口=$PORT 认证=$([ -n "$AUTH_USER" ] && echo "启用($AUTH_USER)" || echo '不启用')"
else
  # 交互式向导
  echo "======================================"
  echo "  myTV SUPER EPG 部署向导"
  echo "======================================"
  read -r -p "监听端口 [默认 8765]: " PORT_IN
  PORT="${PORT_IN:-8765}"
  echo ""
  echo "是否需要用户名+密码访问认证?"
  echo "  0 = 不需要 (公开访问)"
  echo "  1 = 需要 (推荐)"
  read -r -p "选择 [默认 1]: " AUTH_CHOICE_IN
  AUTH_CHOICE="${AUTH_CHOICE_IN:-1}"
  if [ "$AUTH_CHOICE" = "0" ]; then
    AUTH_USER=""
    AUTH_PASS=""
    echo "  -> 公开访问, 不启用认证"
  else
    read -r -p "认证用户名 [默认 admin]: " AU_IN
    AUTH_USER="${AU_IN:-admin}"
    read -r -p "认证密码 [默认 hugo2026+]: " AP_IN
    AUTH_PASS="${AP_IN:-hugo2026+}"
  fi
  echo ""
  echo ">> 部署配置: 端口=$PORT, 认证=$([ -n "$AUTH_USER" ] && echo "启用($AUTH_USER)" || echo '不启用')"
  echo ""
fi
KEEP_ARCHIVE_CRON="${KEEP_ARCHIVE_CRON:-0}"

# ---------- 环境检查 ----------
if [ "$(id -u)" -ne 0 ]; then echo "错误: 请用 root 运行 (sudo bash install.sh)"; exit 1; fi

# 自动检测/安装 Python 3 (>=3.8), 全新 VPS 也能直接部署
PY_BIN=""
find_python() {
  for c in python3 python3.13 python3.12 python3.11 python3.10 python3.9 python3.8; do
    if command -v "$c" >/dev/null 2>&1; then
      if "$c" -c 'import sys; v=sys.version_info; sys.exit(0 if (v.major,v.minor)>=(3,8) else 1)' 2>/dev/null; then
        PY_BIN="$(command -v "$c")"
        return 0
      fi
    fi
  done
  return 1
}
ensure_python() {
  if find_python; then
    echo "== 使用 Python $("$PY_BIN" -c 'import sys;print(f"{sys.version_info.major}.{sys.version_info.minor}")') ($PY_BIN) =="
    return 0
  fi
  echo "== 未找到 Python >=3.8, 尝试自动安装... =="
  if command -v apt-get >/dev/null 2>&1; then
    apt-get update -y && apt-get install -y python3
  elif command -v dnf >/dev/null 2>&1; then
    dnf install -y python3
  elif command -v yum >/dev/null 2>&1; then
    yum install -y python3
  elif command -v apk >/dev/null 2>&1; then
    apk add --no-cache python3
  else
    echo "错误: 未识别系统包管理器, 无法自动安装 Python3" >&2
    echo "      请手动安装 Python 3.8+ 后重试 (https://www.python.org/downloads/)" >&2
    return 1
  fi
  if find_python; then
    echo "== Python 安装成功: $("$PY_BIN" -c 'import sys;print(f"{sys.version_info.major}.{sys.version_info.minor}")') ($PY_BIN) =="
    return 0
  fi
  echo "错误: Python 自动安装失败或版本仍 <3.8, 请手动安装后重试" >&2
  return 1
}
if ! ensure_python; then
  exit 1
fi

BASE=/opt/epg
echo "== 安装文件到 $BASE =="
mkdir -p "$BASE/data"

# ---------- 1) 网页服务主程序 (纯标准库, 零依赖) ----------
install -m 0644 "$(dirname "$0")/epg_server.py" "$BASE/epg_server.py"
"$PY_BIN" - "$PORT" "$AUTH_USER" "$AUTH_PASS" <<'PYEOF'
import re, sys
port, user, pwd = sys.argv[1], sys.argv[2], sys.argv[3]
path = '/opt/epg/epg_server.py'
s = open(path, encoding='utf-8').read()
s = re.sub(r"^PORT = .*$", f"PORT = {int(port)}", s, flags=re.M)
s = re.sub(r"^AUTH_USER = .*$", f"AUTH_USER = '{user}'", s, flags=re.M)
s = re.sub(r"^AUTH_PASS = .*$", f"AUTH_PASS = '{pwd}'", s, flags=re.M)
s = re.sub(r"^TLS_ENABLED = .*$", "TLS_ENABLED = False", s, flags=re.M)  # 默认不启用 TLS
open(path, 'w', encoding='utf-8').write(s)
PYEOF
echo "  ok  epg_server.py (端口=$PORT 认证=$([ -n "$AUTH_USER" ] && echo "启用" || echo '不启用'))"

# ---------- 2) 归档脚本 + 频道配置 (若备份中包含) ----------
D=$(dirname "$0")
if [ -f "$D/epg_archive.sh" ]; then
  install -m 0755 "$D/epg_archive.sh" "$BASE/epg_archive.sh"
  echo "  ok  epg_archive.sh"
fi
if [ -f "$D/mychannels.xml" ]; then
  install -m 0644 "$D/mychannels.xml" "$BASE/mychannels.xml"
  echo "  ok  mychannels.xml"
fi

# ---------- 3) 归档数据 (不覆盖已有) ----------
if [ -d "$D/data" ]; then
  n=0
  for f in "$D"/data/*.xml; do
    [ -e "$f" ] || continue
    b=$(basename "$f")
    if [ ! -e "$BASE/data/$b" ]; then cp "$f" "$BASE/data/$b"; n=$((n+1)); fi
  done
  echo "  ok  data/ 新增 $n 个 XML (已有文件保留)"
fi

# ---------- 4) systemd 服务 ----------
echo "== 配置 systemd 服务 =="
cat > /etc/systemd/system/epg-server.service <<UNITEOF
[Unit]
Description=myTV SUPER EPG web server
After=network.target

[Service]
WorkingDirectory=/opt/epg
ExecStart=$PY_BIN /opt/epg/epg_server.py
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
UNITEOF
systemctl daemon-reload
systemctl enable epg-server.service
systemctl restart epg-server.service
sleep 1
if ! systemctl is-active --quiet epg-server.service; then
  echo "错误: 服务未启动, 日志:" >&2
  journalctl -u epg-server -n 20 --no-pager >&2 || true
  exit 1
fi
echo "  ok  服务 active"

# ---------- 5) 归档定时任务 (可选) ----------
if [ "$KEEP_ARCHIVE_CRON" = "1" ]; then
  if [ -f "$BASE/epg_archive.sh" ]; then
    if ! (crontab -l 2>/dev/null | grep -q 'epg_archive.sh'); then
      (crontab -l 2>/dev/null; echo "17 */6 * * * bash $BASE/epg_archive.sh >/dev/null 2>&1") | crontab -
      echo "  ok  已注册归档 cron (每6小时)"
    else
      echo "  --  cron 已存在, 跳过"
    fi
  else
    echo "  !! 无 epg_archive.sh, 跳过 cron"
  fi
fi

# ---------- 6) 验证 (curl -> wget -> python, 都没有也能跑) ----------
echo "== 验证 =="
if [ -n "$AUTH_USER" ]; then
  CURL_AUTH="-u $AUTH_USER:$AUTH_PASS"
else
  CURL_AUTH=""
fi
LIVE_URL="http://127.0.0.1:$PORT/live"
if command -v curl >/dev/null 2>&1; then
  code=$(curl -s -o /dev/null -w '%{http_code}' $CURL_AUTH "$LIVE_URL" || true)
elif command -v wget >/dev/null 2>&1; then
  code=$(wget -q -O /dev/null --server-response $CURL_AUTH "$LIVE_URL" 2>&1 | awk '/HTTP\//{c=$2} END{print c}')
  code="${code:-000}"
else
  code="$("$PY_BIN" - "$LIVE_URL" <<'PYEOF'
import sys, urllib.request
url = sys.argv[1]
try:
    with urllib.request.urlopen(url, timeout=5) as r:
        print(r.status)
except Exception:
    print('000')
PYEOF
)"
fi
if [ "$code" = "200" ]; then
  echo "✅ 部署成功!"
  echo "   实时查询: http://<本机IP>:$PORT/live"
  echo "   本地归档: http://<本机IP>:$PORT/"
  if [ -n "$AUTH_USER" ]; then
    echo "   认证: $AUTH_USER / $AUTH_PASS"
  else
    echo "   认证: 无 (公开访问)"
  fi
else
  echo "⚠️  服务已启动但 HTTP=$code (可能 curl 代理干扰, 可忽略; 用公网访问验证)"
fi
